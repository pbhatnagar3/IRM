<?php
/*
  User_stats.php
 *-----------------------------------------------------------
 * Author: pbhatnagar3 (Pujun Bhatnagar)
 * Semester: Fall 2013
 * Team: Reinforcement
 *-----------------------------------------------------------
 * Purpose:
 * GUI to test the working of User_stat by reading and displaying all the data
 * for any UserID for any particular assignment.  
 *-----------------------------------------------------------
 * Notes:
 * The user would have to implode the data to display it properly
 * see User_stats.php for reference.
 *-----------------------------------------------------------
 * Last Modified: bnensick3
 * General formatting, and some bug fixing
 */






require_once("user_stats.php");
//require_once("config.php"); // #1 include 
//require_once("classes/ITS_query.php");
//require_once("classes/ITS_summary.php");
//require_once("FILES/PEAR/MDB2.php");
//require_once(INCLUDE_DIR . "include.php");
//include_once('FILES/PEAR/MDB2.php');


/*
$stats = new User_Stats($id,$assignment_num);
		$data= $stats->GetData();
		$concept_name = explode(",",$data['name']);
		$num_attempted = explode(",",$data['count']);
		$num_correct = explode(",",$data['percent']);
		
		
		echo $data;
		echo $concept_name;
		echo $num_attempted;
		
	*/
	echo "<form action=\"UserStatTest.php\" method=\"get\">";
echo "<center>UserID: <input type=\"text\" name=\"UserID\" value=\"1758\"><br>";
echo "Assignment_no: <input type=\"text\" name=\"Assignment_no\" value=\"1\"><br>";
echo "<input type=\"submit\">";
echo "</form>";
	
	
	$UserID=(integer)$_GET["UserID"];
	$Assignment_no=(integer)$_GET["Assignment_no"];
	echo "$game";
		$stats = new user_stats($UserID,$Assignment_no);
		$data= $stats->GetDataDiffFilter();
		var_dump($data);
			
		
		?>
