#Input (student_concept_summary.py user_id,assignment_number)
#Ouput tag_list,attempted,corrected

import sys
import MySQLdb as mdb

def x_axis(assignment_number):
	
	#Open Connection
	db = mdb.connect(host="localhost", user="root",passwd="csip", db="its")
	cur = db.cursor()

	#Grab the IDs
	tag_string = ''
	cur.execute("SELECT orig_tag FROM con_per_assign WHERE assignment=" + assignment_number)
	for i in xrange(cur.rowcount):
		value = cur.fetchone()
		tag_string = value[0]
	print(tag_string)
	tag_ids = tag_string.split(',')
	
	#Take the ID, and get the value
	tag_list = []
	for i in range (0,len(tag_ids)):
		cur.execute("SELECT name FROM tags WHERE id = " + tag_ids[i])
		value = cur.fetchone()
		tag_list.append(value[0])
	
	#Close connection
	cur.close()
	db.close()
	return(tag_list, tag_ids)
def y_axis(assignment_number,user_id,tag_ids):
	
	#Open Connection
	db = mdb.connect(host="localhost", user="root",passwd="csip", db="its")
	cur = db.cursor()
	
	stats_table = "stats_" + user_id
	stats_attempted = []
	stats_correct = []
	
	#For each tag_id
	for i in range (0,len(tag_ids)):
		
		#Add a slot to output
		stats_attempted.append(0)
		stats_correct.append(0)
		
		#Find corresponding questions for each concept
		cur.execute("SELECT questions_id FROM questions_tags WHERE tags_id = 34")
		question_ids = []
		for a in xrange(cur.rowcount):	
			value = cur.fetchone()
			question_ids.append(str(value[0]))
		print question_ids
		#Match corresponding question_ids to chapters and scores
		for j in range (0,len(question_ids)):
			cur.execute("SELECT score FROM " + stats_table + " WHERE current_chapter=" + assignment_number + " AND question_id =" + question_ids[j])
			score = cur.fetchone()
			if score != None and str(score[0]) != 'None':
				#print (str(question_ids[j]) + ' ' + str(score)+  ' ' + str(i) + tag_ids[i])
				stats_correct[i] = stats_correct[i] +float(score[0])/100
				stats_attempted[i] = stats_attempted[i]+1
	
	#print stats_correct
	#print stats_attempted
	#print tag_ids
	
	#Close connection
	cur.close()
	db.close()
	return (stats_attempted, stats_correct)
def filter_concepts(attempted,correct,tag_list):
	
	#remove concepts with 0 attempted
	while True:
		try:
			index = attempted.index(0)
		except:
			break
		attempted.remove(0)
		correct.remove(correct[index])
		tag_list.remove(tag_list[index])
	return (attempted,correct,tag_list)
def sort_concepts(tag_list,attempted,correct):
	tag_list,attempted,correct = zip(*sorted(zip(tag_list,attempted,correct)))
	tag_list = list(tag_list)
	attempted = list(attempted)
	correct = list(correct)
	return (tag_list,attempted,correct)

#Inputs
user_id = str(1758);
assignment_number = str(1);

#Calculating the data
tag_list,tag_ids = x_axis(assignment_number)
attempted,correct = y_axis(assignment_number,user_id,tag_ids)
attempted,correct,tag_list = filter_concepts(attempted,correct,tag_list)
tag_list,attempted,correct = sort_concepts(tag_list,attempted,correct)

print tag_list 
print attempted
print correct
