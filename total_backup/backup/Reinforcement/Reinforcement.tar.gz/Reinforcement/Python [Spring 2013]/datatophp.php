<?php

//Assign Inputs to Python Script
$in2 = "4";
$in1 = 1758;

//Call Python Script
exec("python student_data.py $in1 $in2", $output);

//Assign Output
$out1= ($output[0]);
$out2 = ($output[1]);
$out3 = ($output[2]);

//Print Output
echo "PHP Calling Python Student script for User: ". $in1. " Assignment: ". $in2;
echo"<br/>";
echo "Concepts: ". $out1;
echo"<br/>";
echo "Attempted: ". $out2;
echo"<br/>";
echo "Correct: ". $out3;
echo"<br/>";

//Call Plotting
//exec("python BarGraphGenerator.py);

?>
