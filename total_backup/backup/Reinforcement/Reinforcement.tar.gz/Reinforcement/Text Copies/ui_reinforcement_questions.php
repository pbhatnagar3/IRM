<?php

/*
 * ui_reinforcement_questions.php
 *-----------------------------------------------------------
 * Author: bnensick3
 * Semester: Fall 2013
 * Team: Reinforcement
 *-----------------------------------------------------------
 * "There once was a girl named Lucky, she got hit by a car
 * and died".
 *-----------------------------------------------------------
 * Purpose:
 * Create a GUI to test the ability to identify reinforcement
 * questions.
 * Given (assignment_number, concept) -> (calculate) ->
 * hardest question ID.
 *-----------------------------------------------------------
 * Notes:
 * The input concept should match a concept from the
 * con_per_assign table for the given assignment.
 * See con_per_assign_generator.php to create the table.
 */

//CHECK RELATIVE PATHS
include '../config.php';
include '../classes/ITS_query.php';
include '../FILES/PEAR/MDB2.php';

$file='ui_reinforcement_questions.php'; //Matches file name

echo '<html><body>';
if($_SERVER["REQUEST_METHOD"]!="POST"){
	input_form(0,$file);
}elseif($_POST["ass_num"]<=0 || $_POST["tag_id"]<0){
	input_form(1,$file); //User input error
}else{
	input_form(0,$file);
	$reinforcement_handle = new reinforcement_questions(); //Initialize class
	$output = $reinforcement_handle->main($_POST["ass_num"],$_POST["tag_id"]);
};
echo '</body></html>';


/*
 * Function input_form(form_status, file)
 * ----------------------------------------------------------
 * Variables:
 * form_status - state based variable (0 or 1) 1 = user input
 * error.
 * file - see definition above.
 *-----------------------------------------------------------
 * Purpose:
 * Create an input form that accepts a concept id (numeric)
 * and assignment number (numeric) via HTML.
 * Calculate button calculate the hardest question of the
 * given concept in the given assignment.	
 */

function input_form($form_status,$file){
	//Check for previous input error
  	if($form_status){
  		print '<center><bold><font color="red">Assignment Number MUST be > 0! </font></bold
	      	</center><br>';
  	} 
  	print	"<form	action={$file}	method='POST'>";
  	print '<table align="center">';	
  	print	'<tr><td>Assignment Number:</td>
		<td><input	type="text"	name="ass_num"	value=1><br></td></tr>'; //Defaults to 1
  	print	'<tr><td>Concept ID:</td>
		<td><input	type="text"	name="tag_id" value=1><br></td></tr>'; //Defaults to 1	
  	print '<tr><td colspan="2" align="center"><center>
		<input type="submit"value="Calculate"></center></td></tr>'; //Standard submit button
  	print '</table></form><br>';
 }

/*
 * Class reinforcement_questions(ass_num, tag_id)
 * ----------------------------------------------------------
 * Variables:
 * ass_num - user input: assignment number
 * tag_id - user input: tag_id
 *-----------------------------------------------------------
 * Purpose:
 * Calculate the hardest question in an assignment for a
 * given tag id.	
 */

class reinforcement_questions{

	//Class based variables
	public $db_dsn;
	public $tb_name;
	public $mdb2;
	public $ass_num; //user input
	public $tag_id;  //user input
	

    	/*
 	 * Function __construct(ass_num, tag_id)
 	 *-----------------------------------------------------------
 	 * Purpose:
 	 * Basic constructor assignment.
	 * Setup MySQL	
 	 */

    	function __construct($ass_num,$tag_id){
        	global $db_dsn,  $tb_name ;
		$this->diff = 'difficultySTD'; //Picked one
        	$this->db_dsn = $db_dsn;
        	$this->tb_name = $tb_name;
        	$this->MySQL_set(); //connect to database
    	 }

	/*
 	 * Function __destruct
 	 * ----------------------------------------------------------
 	 * Purpose:
 	 * Basic destructor
	 * End MySQL	
 	 */
    	function __destruct(){
		$this->MySQL_end(); //disconnect to database
	}

	/*
 	 * Function main
 	 * ----------------------------------------------------------
 	 * Variables:
 	 * ass_num - user input: assignment number
 	 * tag_id - user input: tag_id
	 * ----------------------------------------------------------
 	 * Purpose:
 	 * Handles all the routines
 	 */
	function main($ass_num,$tag_id){
		$this->ass_num = $ass_num; //user input
		$this->tag_id = $tag_id; //user input
		$questions_in_assign = $this->questions_in_assign();
		$questions_per_concept = $this->questions_per_concept();
		$questions_overlap = array_values(array_intersect($questions_in_assign,$questions_per_concept));
		$question_difficulty = $this-> question_difficulty($questions_overlap);
		$reinforcement_question_index= implode(",",array_keys($question_difficulty, max($question_difficulty))); //Work around for max function not having an index
		echo "Assignment: ", $this->ass_num, " Tag ID: ", $this->tag_id, " Question ID: ",$questions_overlap[$reinforcement_question_index]; 
		return ($questions_overlap[$reinforcement_question_index]);
	}
	
	/****FUNCTION INSTRUCTIONS*************************************
	* Extracts a column out of a 2d array and returns it in an array
	* array=your 2d array
	* col=the column you want to pull out 
	**************************************************************/

	function GetCol($array,$col){
		foreach($array as $row) $new[] = $row[$col];
		return $new;
	}

	/*
 	 * Function questions_in_assign
 	 *-----------------------------------------------------------
 	 * Purpose:
 	 * Finds all questions in an assignment. No such table exists
	 * therefore, a complex querry is used.
	 *-----------------------------------------------------------
	 * Output:
	 * question_list(array)- questions in the assignment
	 *-----------------------------------------------------------
	 * Note:
	 * In the future, if a table is made for questions/assign use
	 * said table
 	 */

	function questions_in_assign(){
        	$ITSq = new ITS_query();
		$resource_source = $ITSq->getCategory($this->ass_num);
        	$query = 'SELECT id FROM ' . $this->tb_name . ' WHERE ' . $resource_source;
		//echo $query; //Uncomment this if you are interested in query or database structure changes
        	$qarr =$this->Query($query,0,0);
        	$qarr = $this->GetCol($qarr,0);
		$question_list = $qarr;   
        	return $question_list;
	}
	
	/*
 	 * Function questions_per_concept
 	 *-----------------------------------------------------------
 	 * Purpose:
 	 * Finds all questions for a concept
	 *-----------------------------------------------------------
	 * Output:
	 * question_list(array)- questions for a concept
 	 */
	
	function questions_per_concept(){
        	$ITSq = new ITS_query();
        	$query = 'SELECT questions_id FROM questions_tags WHERE tags_id = ' .$this->tag_id;
		//echo $query; //Uncomment this if you are interested in query or database structure changes
        	$qarr =$this->Query($query,0,0);
        	$qarr = $this->GetCol($qarr,0);
		$question_list = $qarr;
		//The next query is a sanity check
		$query = 'SELECT q_id FROM questions_difficulty WHERE q_id IN (' .implode(',',$question_list). ')';
		//echo $query; //Uncomment this if you are interested in query or database structure changes
        	$qarr =$this->Query($query,0,0);
        	$qarr = $this->GetCol($qarr,0);
		$question_list = $qarr;    
        	return $question_list;
	}
	
	/*
 	 * Function question_difficulty
 	 *-----------------------------------------------------------
 	 * Purpose:
 	 * Find the difficulty of an array of questions
	 *-----------------------------------------------------------
	 * Input:
	 * question_ids
	 * Output:
	 * $question_difficulty
 	 */

	function question_difficulty($question_ids){
		$ITSq = new ITS_query();
        	$query = 'SELECT ' .$this->diff.' FROM questions_difficulty WHERE q_id IN (' .implode(',',$question_ids). ')';
		//echo $query; //Uncomment this if you are interested in query or database structure changes
        	$qarr =$this->Query($query,0,0);
        	$qarr = $this->GetCol($qarr,0);
		$question_difficulty = $qarr;   
        	return $question_difficulty;
	}

	/*
 	 * Function MySQL_set
 	 *-----------------------------------------------------------
 	 * Purpose:
 	 * Connect to ITS database
 	 */

	function MySQL_set(){
		//Connect to database
		$this->mdb2 =& MDB2::connect($this->db_dsn);
        	if (PEAR::isError($this->mdb2)) {
            		throw new Exception($this->mdb2->getMessage());
        	}
        	return 1;
   	}

	/*
 	 * Function MySQL_end
 	 *-----------------------------------------------------------
 	 * Purpose:
 	 * Disconnect to ITS database
 	 */

	function MySQL_end(){
		$this->mdb2->disconnect();
		return 1;
	}

	/****FUNCTION INSTRUCTIONS*************************************
	* queries the MySQL database
	* query=the query you would like to send
	* assoc=if you would like the array to use the field names as indices
	* 			TRUE=yes    FALSE=no
	**************************************************************/

	function Query($query,$assoc){	
        	//run query
		$res = $this->mdb2->query($query);
		if (PEAR::isError($res)) {
            		throw new Question_Control_Exception($res->getMessage());
        	}	
        	if($assoc){
			$answer = $res->fetchAll(PDO::FETCH_ASSOC);
		}else{
			$answer = $res->fetchAll();
		}
		return $answer;
	}
}

?>
