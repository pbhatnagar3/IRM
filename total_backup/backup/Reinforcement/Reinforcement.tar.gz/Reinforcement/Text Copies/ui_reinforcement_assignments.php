<?php

/*
 * ui_reinforcement_questions.php
 *-----------------------------------------------------------
 * Author: bnensick3
 * Semester: Fall 2013
 * Team: Reinforcement
 *-----------------------------------------------------------
 * "There once was a girl named Lucky, she got hit by a car
 * and died".
 *-----------------------------------------------------------
 * Purpose:
 * Create a GUI to test the ability to identify reinforcement
 * questions.
 * Given (assignment_number) -> (calculate) ->
 * hardest question ID for all critical concepts.
 *-----------------------------------------------------------
 * Notes:
 * con_per_assign table must exist!
 * See con_per_assign_generator.php to create the table.
 */

//CHECK RELATIVE PATHS
require_once 'reinforcement.php';


$file='ui_reinforcement_assignments.php'; //Matches file name

echo '<html><body>';
if($_SERVER["REQUEST_METHOD"]!="POST"){
	input_form(0,$file);
}elseif($_POST["ass_num"]<=0){
	input_form(1,$file); //User input error
}else{
	input_form(0,$file);
	$reinforcement_handle = new reinforcement($_POST["diff"]); //Initialize class
	$output = $reinforcement_handle->generate_questions($_POST["ass_num"]);
};
echo '</body></html>';


/*
 * Function input_form(form_status, file)
 * ----------------------------------------------------------
 * Variables:
 * form_status - state based variable (0 or 1) 1 = user input
 * error.
 * file - see definition above.
 *-----------------------------------------------------------
 * Purpose:
 * Create an input form that accepts a concept id (numeric)
 * and assignment number (numeric) via HTML.
 * Calculate button calculate the hardest question of the
 * given concept in the given assignment.	
 */

function input_form($form_status,$file){
	//Check for previous input error
  	if($form_status){
  		print '<center><bold><font color="red">Assignment Number MUST be > 0! </font></bold
	      	</center><br>';
  	} 
  	print	"<form	action={$file}	method='POST'>";
  	print '<table align="center">';	
  	print	'<tr><td>Assignment Number:</td>
		<td><input	type="text"	name="ass_num"	value=1><br></td></tr>'; //Defaults to 1
	print	'<tr><td>Difficulty Alogrithm:</td>
		<td><input	type="text"	name="diff"	value="difficultySTD"><br></td></tr>'; //Defaults difficultySTD	
  	print '<tr><td colspan="2" align="center"><center>
		<input type="submit"value="Calculate"></center></td></tr>'; //Standard submit button
  	print '</table></form><br>';
 }

?>
